@main = {
	pizza: {
		name: 'Pizza',
		price: 4.05
	},
	tacos: {
		name: 'Tacos',
		price: 3.55
	},
	burger: {
		name: 'Burger',
		price: 5.05
	},
	lasagna: {
		name: 'Lasagna',
		price: 4.55
	}
}

def main_menu
	puts "What would you like to eat?"
	puts @main[:pizza][:name], @main[:pizza][:price]
end

main_menu

